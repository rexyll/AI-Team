# 部署冒烟验证报告（Smoke Report）

- 状态：**PASSED**
- 命令：`F:\workspace\_coding_workspace\AI-Team\ai-dev-team\.venv\Scripts\python.exe -m pytest tests/test_csv_parser.py tests/test_validator.py -q`
- 生成时间：2026-09-26T02:31:44.311004Z
